import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_application_1/post.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'exercicio http',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final _postIdController = TextEditingController(text: '1');
  final _userIdController = TextEditingController(text: '1');
  final _titleController = TextEditingController(text: 'titulo');
  final _bodyController = TextEditingController(text: 'conteudo');

  bool _loading = false;
  String _operation = 'Nenhuma requisicao executada.';
  String _result = 'Use os botoes acima para testar GET, POST, PUT e DELETE.';
  final List<Post> _posts = [];

  static final Uri _postsUrl = Uri.https(
    'jsonplaceholder.typicode.com',
    'posts',
  );

  @override
  void dispose() {
    _postIdController.dispose();
    _userIdController.dispose();
    _titleController.dispose();
    _bodyController.dispose();
    super.dispose();
  }

  Future<void> _execute(
    String operation,
    Future<http.Response> Function() request,
  ) async {
    setState(() {
      _loading = true;
      _operation = operation;
      _result = 'executando';
    });

    try {
      final response = await request();
      setState(() {
        _result = _formatResponse(response);
      });
    } catch (error) {
      setState(() {
        _result = 'erro: \n$error';
      });
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  Future<void> _getPost() async {
    await _execute('GET /posts/$_postId', () {
      final post = _findPost(_postId);
      if (post == null) {
        return Future.value(
          http.Response(
            jsonEncode({'erro': 'Post nao encontrado no banco '}),
            404,
          ),
        );
      }
      return Future.value(http.Response(post.toJson(), 200));
    });
  }

  Future<void> _getPostsList() async {
    await _execute('GET /posts', () {
      return Future.value(http.Response(_postsToJson(), 200));
    });
  }

  Future<void> _createPost() async {
    await _execute('POST /posts', () async {
      final post = Post(
        _userId,
        _nextPostId,
        _titleController.text,
        _bodyController.text,
      );
      final response = await http.post(
        _postsUrl,
        headers: _headers,
        body: post.toJson(),
      );
      setState(() {
        _posts.add(post);
      });
      return http.Response(post.toJson(), response.statusCode);
    });
  }

  Future<void> _updatePost() async {
    await _execute('PUT /posts/$_postId', () async {
      final index = _posts.indexWhere((post) => post.id == _postId);
      if (index < 0) {
        return http.Response(
          jsonEncode({'erro': 'Post nao encontrado no banco '}),
          404,
        );
      }

      final post = Post(
        _userId,
        _postId,
        _titleController.text,
        _bodyController.text,
      );
      final response = await http.put(
        _postUrl(_postId),
        headers: _headers,
        body: post.toJson(),
      );
      setState(() {
        _posts[index] = post;
      });
      return http.Response(post.toJson(), response.statusCode);
    });
  }

  Future<void> _deletePost() async {
    await _execute('DELETE /posts/$_postId', () async {
      final exists = _posts.any((post) => post.id == _postId);
      if (!exists) {
        return http.Response(
          jsonEncode({'erro': 'Post nao encontrado no banco '}),
          404,
        );
      }

      final response = await http.delete(_postUrl(_postId), headers: _headers);
      setState(() {
        _posts.removeWhere((post) => post.id == _postId);
      });
      return response;
    });
  }

  Uri _postUrl(int id) {
    return Uri.https('jsonplaceholder.typicode.com', 'posts/$id');
  }

  Map<String, String> get _headers {
    return {'Content-Type': 'application/json; charset=UTF-8'};
  }

  int get _postId {
    return int.tryParse(_postIdController.text) ?? 1;
  }

  int get _userId {
    return int.tryParse(_userIdController.text) ?? 1;
  }

  int get _nextPostId {
    if (_posts.isEmpty) {
      return 1;
    }
    final ids = _posts.map((post) => post.id).toList();
    ids.sort();
    return ids.last + 1;
  }

  String _formatResponse(http.Response response) {
    final body = response.body.isEmpty ? '{}' : response.body;
    return 'Status: ${response.statusCode}\n'
        'Posts salvos no banco : ${_posts.length}\n\n'
        '${_prettyJson(body)}';
  }

  String _prettyJson(String source) {
    try {
      final encoder = const JsonEncoder.withIndent('  ');
      return encoder.convert(jsonDecode(source));
    } catch (_) {
      return source;
    }
  }

  String _postsToJson() {
    final postsMap = _posts.map((post) => jsonDecode(post.toJson())).toList();
    return jsonEncode(postsMap);
  }

  Post? _findPost(int id) {
    for (final post in _posts) {
      if (post.id == id) {
        return post;
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Requisicoes HTTP')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildForm(),
              const SizedBox(height: 16),
              _buildActions(),
              const SizedBox(height: 16),
              _buildResult(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _postIdController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'ID do post',
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: TextField(
                controller: _userIdController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'ID do usuario',
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _titleController,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            labelText: 'Titulo',
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _bodyController,
          minLines: 3,
          maxLines: 5,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            labelText: 'Corpo',
          ),
        ),
      ],
    );
  }

  Widget _buildActions() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        FilledButton(
          onPressed: _loading ? null : _getPost,
          child: const Text('GET'),
        ),
        FilledButton.tonal(
          onPressed: _loading ? null : _getPostsList,
          child: const Text('GET lista'),
        ),
        FilledButton.tonal(
          onPressed: _loading ? null : _createPost,
          child: const Text('POST'),
        ),
        FilledButton.tonal(
          onPressed: _loading ? null : _updatePost,
          child: const Text('PUT'),
        ),
        FilledButton.tonal(
          onPressed: _loading ? null : _deletePost,
          child: const Text('DELETE'),
        ),
      ],
    );
  }

  Widget _buildResult() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  _operation,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              if (_loading)
                const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
            ],
          ),
          const SizedBox(height: 8),
          SelectableText(_result),
        ],
      ),
    );
  }
}
